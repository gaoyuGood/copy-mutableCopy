//
//  Cat.h
//  copy和mutableCopy
//
//  Created by 高宇 on 2019/1/14.
//  Copyright © 2019 admin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Cat : NSObject

@property (nonatomic,copy)NSString *catName;

-(id)copyWithZone:(NSZone *)zone;

@end
