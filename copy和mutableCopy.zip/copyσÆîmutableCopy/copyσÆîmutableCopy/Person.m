//
//  Person.m
//  copy和mutableCopy
//
//  Created by admin on 2018/7/17.
//  Copyright © 2018年 admin. All rights reserved.
//

#import "Person.h"

@implementation Person
-(id)copyWithZone:(NSZone *)zone{
    Person *copy = [[[self class] allocWithZone:zone] init];
    copy->_name = [_name copy];
    //copy.name = self.name;
    return copy;
}

//为每个属性创建新的空间，并将内容复制
//    copy.name = [[NSString alloc] initWithString:self.name];
//    return copy;


// 归档需要实现的方法
// 1.编码方法
- (void)encodeWithCoder:(NSCoder *)aCoder {
    [aCoder encodeObject:self.name forKey:@"PersonName"];
}

// 2.解码方法
- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    if (self = [super init]) {
        self.name = [aDecoder decodeObjectForKey:@"PersonName"];
    }
    return self;
}


@end
