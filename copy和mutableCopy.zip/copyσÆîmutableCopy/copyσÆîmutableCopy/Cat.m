//
//  Cat.m
//  copy和mutableCopy
//
//  Created by 高宇 on 2019/1/14.
//  Copyright © 2019 admin. All rights reserved.
//

#import "Cat.h"

@implementation Cat

-(id)copyWithZone:(NSZone *)zone{
    Cat *copy = [[[self class] allocWithZone:zone] init];
    copy->_catName = [_catName copy];
    return copy;
}

@end
