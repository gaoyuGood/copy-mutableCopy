//
//  ViewController.m
//  copy和mutableCopy
//
//  Created by admin on 2018/7/17.
//  Copyright © 2018年 admin. All rights reserved.
//

#import "ViewController.h"
#import "Person.h"
#import "Cat.h"

@interface ViewController ()
@property (nonatomic,strong)NSString *string;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    // 1.非容器类 不可变对象
//    [self immutableObject];
    
    // 2.非容器类 可变对象
//    [self mutableObject];
    
    // 3.浅复制容器类对象
//    [self shallowCopyCollections];
    
    // 4.自定义对象
//    [self personCopy];

    // 5.数组存放自定义对象
//    [self arrayPersonCopy];

    // 6.更改指针指向地址
//    [self pointToAnotherMemoryAddress];
    
    // 7.属性中copy与strong特性的区别
//    [self copyORstrong];
}

// 非容器类 不可变对象
- (void)immutableObject {
    // 1.创建一个string字符串。
    NSString *string = @"Jason Mraz";
    NSString *stringB = string;
    NSString *stringCopy = [string copy];
    NSString *stringMutableCopy = [string mutableCopy];
    
    // 2.输出指针指向的内存地址。
    NSLog(@"string = %p",string);
    NSLog(@"stringB = %p",stringB);
    NSLog(@"stringCopy = %p",stringCopy);
    NSLog(@"stringMutableCopy = %p",stringMutableCopy);
}

// 2.非容器类 可变对象
- (void)mutableObject {
    // 1.创建一个可变字符串。
    NSMutableString *mString = [NSMutableString stringWithString:@"Coca Cola"];
    NSString *mStringCopy = [mString copy];
    NSMutableString *mutablemString = [mString copy];
    NSMutableString *mStringMutableCopy = [mString mutableCopy];
    
    // 2.在可变字符串后添加字符串。
    [mString appendString:@"AA"];
    [mutablemString appendString:@"BB"];  // 运行时，这一行会报错。
    [mStringMutableCopy appendString:@"CC"];
    
    // 3.输出指针指向的内存地址。
    NSLog(@"Memory location of \n mString = %p,\n mstringCopy = %p,\n mutablemString = %p,\n mStringMutableCopy = %p",mString, mStringCopy, mutablemString, mStringMutableCopy);
}

// 3.容器类对象。
- (void)shallowCopyCollections {
    // 1.创建一个不可变数组，数组内元素为可变字符串。
    NSMutableString *red = [NSMutableString stringWithString:@"Red"];
    NSMutableString *green = [NSMutableString stringWithString:@"Green"];
    NSMutableString *blue = [NSMutableString stringWithString:@"Blue"];
    NSArray *myArray1 = [NSArray arrayWithObjects:red, green, blue, nil];
    
    // 2.进行浅复制。
    NSArray *myArray2 = [myArray1 copy];
    NSMutableArray *myMutableArray3 = [myArray1 mutableCopy];
    NSArray *myArray4 = [[NSArray alloc] initWithArray:myArray1];
    
    // 3.修改myArray2的第一个元素。
    NSMutableString *tempString = myArray2.firstObject;
    [tempString appendString:@"Color"];  //第一个元素添加Color
    
    // 4.输出四个数组内存地址及四个数组内容。
    NSLog(@"Memory location of \n myArray1 = %p, \n myArray2 %p, \n myMutableArray3 %p, \n myArray4 %p",myArray1, myArray2, myMutableArray3, myArray4);
    NSLog(@"Contents of \n myArray1 %@, \n myArray2 %@, \n myMutableArray3 %@, \n myArray4 %@",myArray1, myArray2, myMutableArray3, myArray4);
}

// 4.自定义对象
- (void)personCopy {
    //model可变对象, 测试copy的意义:会生成新的地址,如果用=就是指向相同的地址
    Person *person = [Person new];
    person.name = @"qqq";
    Person *newPerson = [Person new];
    
    newPerson = [person copy];
    
    NSLog(@"person=%p",person);
    NSLog(@"newPerson=%p",newPerson);
    
    newPerson.name = @"PPP";
    
    NSLog(@"person=%p",person);
    NSLog(@"newPerson=%p",newPerson);
}

// 5.数组存放自定义对象
- (void)arrayPersonCopy {
    //copy两块内存地址不一样  深拷贝
    Person *person = [Person new];
    person.name = @"qqq";
    
    Person *newPerson = [Person new];
    newPerson.name = @"www";
    
    //单层深拷贝   内部自定义变量还是指向同一地址  会根据内容改变
    NSArray *listArr = @[person,newPerson];
    NSLog(@"listArr == %@",listArr);
    
    Person *eee = listArr[0];
    eee.name = @"111";
    
    
    NSArray *arr = [listArr mutableCopy];
    
//    //第一种方案
//    NSArray *arr = [NSArray array];
//    NSMutableArray *tempArr = [NSMutableArray array];
//    for (Person *tempP in listArr) {
//        Person *newPerson = [tempP copy];
//        [tempArr addObject:newPerson];
//    }
//    arr = tempArr;
    
//    //第二种方案   必须容器的内部元素都实现NSCopying协议
//    NSArray *arr = [[NSArray alloc] initWithArray:listArr copyItems:YES];
    
//    //第三种方案
//    NSArray *arr = [NSKeyedUnarchiver unarchiveObjectWithData:[NSKeyedArchiver archivedDataWithRootObject: listArr]];
    
    Person *ddd = listArr[0];
    ddd.name = @"asjdkasjkdakjas";
    
    NSLog(@"%@",arr);
}

// 6.更改指针指向地址
- (void)pointToAnotherMemoryAddress {
    // 1.指针a、b同时指向字符串pro
    NSString *a = @"pro";
    NSString *b = a;
    NSLog(@"Memory location of \n a = %p, \n b = %p", a, b);
    // 断点1位置
    
    // 2.指针a指向字符串pro648
    a = @"pro648";
    NSLog(@"Memory location of \n a = %p, \n b = %p", a, b);
    // 断点2位置
}

// 7.属性中copy与strong特性的区别
- (void)copyORstrong {
    NSMutableString *mutableString = [[NSMutableString alloc] initWithString:@"test"];
    self.string = mutableString;
    NSLog(@"%@", self.string);
    [mutableString appendString:@"addstring"];
    NSLog(@"%@", self.string);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
